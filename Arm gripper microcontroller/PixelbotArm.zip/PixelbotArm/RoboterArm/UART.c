#include "UART.h"

uint8_t ready = 0;
uint8_t ending = 0;
char receiveBuffer[BUFFER];
char decodeBuffer[BUFFER];
int decodeLength;
volatile uint8_t receiveBufferSize = 0;
char test;
ISR(USART0_RXC_vect){
	if (USART0_STATUS & USART_RXCIF_bm)
	{
		uint8_t temp;
		temp = USART0_RXDATAL;
		receiveBuffer[receiveBufferSize] = temp;
		receiveBufferSize++;
		if(temp == 0x0D){
			ending = 1;
		}
		if (temp == 0x0A && ending ==1)
		{
			ending = 0;
			ready = 1;
			receiveBuffer[receiveBufferSize]=0;
			receiveBufferSize=0;
		}
		
		USART0_STATUS |= USART_RXCIF_bm;
	}
}

int8_t USART_init(){
	PORTA.DIRSET = PIN1_bm; // TX pin as output
	PORTA.OUTCLR = PIN1_bm; //

	PORTA.DIRCLR = PIN2_bm; // RX pin set as input
	PORTA.PIN2CTRL &= ~PORT_PULLUPEN_bm; // Leave it as pulled-off
	
	PORTMUX.CTRLB |= PORTMUX_USART0_bm;

	USART0.BAUD = (uint16_t)USART0_BAUD_RATE(19200); /* set baud rate register */

	USART0.CTRLA = USART_RXCIE_bm;
	USART0.CTRLB = 0 << USART_MPCM_bp       /* Multi-processor Communication Mode: disabled */
	| 0 << USART_ODME_bp     /* Open Drain Mode Enable: disabled */
	| 1 << USART_RXEN_bp     /* Receiver enable: enabled */
	| USART_RXMODE_NORMAL_gc /* Normal mode */
	| 0 << USART_SFDEN_bp    /* Start Frame Detection Enable: disabled */
	| 1 << USART_TXEN_bp;    /* Transmitter Enable: enabled */

	USART0.CTRLC = USART_CMODE_ASYNCHRONOUS_gc /* Asynchronous Mode */
	| USART_CHSIZE_8BIT_gc /* Character size: 8 bit */
	| USART_PMODE_DISABLED_gc /* No Parity */
	| USART_SBMODE_1BIT_gc; /* 1 stop bit */


	return 0;
}

void USART_write(const uint8_t data)
{
	while (!(USART0.STATUS & USART_DREIF_bm));
	USART0.TXDATAL = data;
}

void printString(const char myString[]) {
	uint8_t i = 0;
	while (myString[i]) {
		USART_write((int)myString[i]);
		//sendChar(myString[i]);
		i++;
	}
}
int hex2int(char ch)
{
	if (ch >= '0' && ch <= '9')
	return ch - '0';
	if (ch >= 'A' && ch <= 'F')
	return ch - 'A' + 10;
	if (ch >= 'a' && ch <= 'f')
	return ch - 'a' + 10;
	return -1;
}
uint32_t string2uint32 (char *ch){
	decodeLength = strlen(ch);
	if (decodeLength >= 1 && ch[0] != 0x0D)
	{

		uint32_t decodeInt = 0;
		for (int i = 0; i< decodeLength;i++) decodeInt = decodeInt + (uint32_t)((uint32_t)hex2int(ch[i])<<(uint32_t)(decodeLength*4-(i+1)*4));
		/*#ifdef DEBUG
		printString(ch);
		char buf[16];
		snprintf(buf, 16, "->%lu-ok!\r\n", decodeInt);
		printString(buf);
		#endif*/
		return decodeInt;
	}
	return -1;
}
void decodeCommand(){
	
	if (ready)
	{
		ready=0;
		if ((receiveBuffer[0] == '$' || receiveBuffer[1] == '$') && strlen(receiveBuffer) >= 3)
		{
			for (int i=0;i<BUFFER;i++){
				if (receiveBuffer[i] == 0x0D || receiveBuffer[i] == 0x0A) decodeBuffer[i] = 0x00;
				else decodeBuffer[i] = receiveBuffer[i];
				if(receiveBuffer[i] == 0x00){
					break;
				}
			}
			char *command = strtok(decodeBuffer, ",");
			if (command[0] >= 127)
			{
				command ++;
			}
			if (strcmp(command, "$APY") == 0)
			{
				setPosition(Y, string2uint32(strtok(0, ",")), true);
				
			}
			else if (strcmp(command, "$APZ") == 0)
			{
				setPosition(Z, string2uint32(strtok(0, ",")), true);
			}
			else if (strcmp(command, "$APA") == 0)
			{
				setPosition(A, string2uint32(strtok(0, ",")), true);
			}
			else if (strcmp(command, "$APB") == 0)
			{
				moveServo(string2uint32(strtok(0, ",")));
				printString("$OK");
			}
			else if (strcmp(command, "$ACD") == 0)
			{
				for (int i = 0; i < motorCount; i++) {
					disableMotor(i);
				}
			}
			else if (strcmp(command, "$ACE") == 0)
			{
				for (int i = 0; i < motorCount; i++) {
					enableMotor(i);
				}
			}
			else if (strcmp(command, "$ACH") == 0)
			{
				for (int i = motorCount-1; i >= 0; i--) {
					enableMotor(i);
					homeMotor(i);
				}
				printString("$OK");
			}
			//printString("\r\nAfterIf\r\n");
		}
		resetReceiver();
	}
}
void resetReceiver(void){
	ready = 0;
	ending = 0;
	for (int i=0;i<BUFFER;i++){
		receiveBuffer[i] = 0;
		decodeBuffer[i] = 0;
	}
}