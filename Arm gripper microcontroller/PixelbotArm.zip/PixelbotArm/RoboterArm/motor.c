/*
 * motor.c
 *
 * Created: 10.01.2024 01:04:12
 *  Author: nilsk
 */ 
#include "motor.h"

int motorDelay[] = {40, 40, 40};
	
//					  82,5cm   
uint32_t motorMax[] = {16050, 43050, 6000};
uint32_t motorFactor[] = {20, 103, 19};
uint32_t motorMinimum[] = {0, 0, 55};
volatile uint32_t TCB_Time;
volatile uint32_t nextStepTime [motorCount];
uint32_t motorPosition [motorCount];
int motorMove [motorCount];
bool motorPulse [motorCount];
bool motorStateChanged [motorCount];
uint32_t targetPosition [motorCount];
bool dir[motorCount];

ISR(TCB0_INT_vect)
 {
	TCB_Time ++;
	TCB0.INTFLAGS = TCB_CAPT_bm;
}

void timerBInit(void)
{

	TCB0.CCMP = 0x00B4; /* Compare or Capture: 0xffff */ //20us

	TCB0.CNT = 0x00B4; /* Count: 0xffff */

	// TCB0.CTRLB = 0 << TCB_ASYNC_bp /* Asynchronous Enable: disabled */
	//		 | 0 << TCB_CCMPEN_bp /* Pin Output Enable: disabled */
	//		 | 0 << TCB_CCMPINIT_bp /* Pin Initial State: disabled */
	//		 | TCB_CNTMODE_INT_gc; /* Periodic Interrupt */

	TCB0.DBGCTRL = 1 << TCB_DBGRUN_bp; /* Debug Run: enabled */

	// TCB0.EVCTRL = 0 << TCB_CAPTEI_bp /* Event Input Enable: disabled */
	//		 | 0 << TCB_EDGE_bp /* Event Edge: disabled */
	//		 | 0 << TCB_FILTER_bp; /* Input Capture Noise Cancellation Filter: disabled */

	TCB0.INTCTRL = 1 << TCB_CAPT_bp /* Capture or Timeout: enabled */;

	TCB0.CTRLA = TCB_CLKSEL_CLKDIV1_gc  /* CLK_PER/2 (From Prescaler) */
	| 1 << TCB_ENABLE_bp   /* Enable: enabled */
	| 0 << TCB_RUNSTDBY_bp /* Run Standby: disabled */
	| 0 << TCB_SYNCUPD_bp; /* Synchronize Update: disabled */

}

void stepperInit(void){	
	timerAInit();
	timerBInit();
	
	for (int i = 0; i < motorCount; i++) {
		printString(".");
		enableMotor(i);
		homeMotor(i);
	}
}

void handleStepper(void){
	for (int i = 0; i < motorCount; i++) {
		controllPosition(i);
	}
}


void disableMotor (int m){
	switch(m){
		case Y:
		PORTB.OUT |= (PIN1_bm);
		break;
		case Z:
		PORTA.OUT |= (PIN5_bm);
		break;
		case A:
		PORTC.OUT |= (PIN2_bm);
		break;
	}
	//digitalWrite(enablePin[m], HIGH);
}

void enableMotor (int m){
	switch(m){
		case Y:
		PORTB.OUT &= ~(PIN1_bm);
		break;
		case Z:
		PORTA.OUT &= ~(PIN5_bm);
		break;
		case A:
		PORTC.OUT &= ~(PIN2_bm);
		break;
	}
}

void dirMotor (int m, bool d){
	switch(m){
		case Y:
		if (d) PORTA.OUT |= (PIN7_bm);
		else PORTA.OUT &= ~(PIN7_bm);
		break;
		case Z:
		if (d) PORTA.OUT |= (PIN4_bm);
		else PORTA.OUT &= ~(PIN4_bm);
		break;
		case A:
		if (d) PORTC.OUT &= ~(PIN1_bm);
		else PORTC.OUT |= (PIN1_bm);
		break;
	}
}

bool readEndstop (int m){
	switch(m){
		case Y:
		return (PORTA.IN & PIN3_bm) >> PIN3_bp;
		break;
		case Z:
		return ((~PORTB.IN & PIN2_bm) >> PIN2_bp); //reversed because of Hardware 
		break;
		case A:
		return ((PORTB.IN & PIN5_bm) >> PIN5_bp);
		break;
		default:
		return false;
	}
}

void stepMotor (int m){
	switch(m){
		case Y:
		PORTB.OUT ^= PIN0_bm;
		break;
		case Z:
		PORTA.OUT ^= PIN6_bm;
		break;
		case A:
		PORTC.OUT ^= PIN3_bm;
		break;
	}
}

void homeMotor (int m){
	dirMotor(m, false);

	while(readEndstop(m)){
		if (nextStepTime[m] <= TCB_Time)
		{
			nextStepTime[m] = TCB_Time + motorDelay[m];
			stepMotor(m);
		}
	}
	motorPosition[m] = 0;
	targetPosition[m] = 0;
	setPosition (m, 0, false);
}

void setPosition (int m, uint32_t p, bool state){
	p = (p + motorMinimum[m]) * motorFactor[m];
	if (p >= motorMax[m]) p = motorMax[m];
	targetPosition[m] = p;
	dir[m] = (motorPosition[m] < targetPosition[m]);
	dirMotor(m, dir[m]);
	if (state)
	{
		motorStateChanged[m] = 1;
	}
}

uint32_t getPosition (int m){
	return motorPosition[m];
}

void controllPosition(int m){
	if(motorPosition[m] != targetPosition[m]){
		if (nextStepTime[m] <= TCB_Time)
		{
			if (dir[m])
			{
				nextStepTime[m] = TCB_Time + motorDelay[m];
				stepMotor(m);
				motorPosition[m] ++;
			}
			else if (readEndstop(m))
			{
				nextStepTime[m] = TCB_Time + motorDelay[m];
				stepMotor(m);
				motorPosition[m] --;
				
			}
			else
			{
				motorPosition[m] = 0;
			}
		}
	}
	else if (motorStateChanged[m])
	{
		motorStateChanged[m] = 0;
		switch(m){
			case Y:
				printString("$OK");
			break;
			case Z:
				printString("$OK");
			break;
			case A:
				printString("$OK");
			break;
		}
	}
}
void moveServo(int per) // 0 - 100 -> 988us - 2012us
{
	if (per > 100)
	{
		per = 100;
	}
	else if (per <= 0)
	{
		per = 0;
	}
	per = 100-per;
	TCA0.SPLIT.HCMP1 = (per * ((float)(ServoMax-ServoMin)/100.0) + ServoMin);
}

void timerAInit(void)
{
	PORTMUX.CTRLC |= (PORTMUX_TCA04_bm);
	
	TCA0.SPLIT.LPER = 255;
	TCA0.SPLIT.HPER = 255;
	
	moveServo(0);
	
	TCA0.SPLIT.CTRLD |= (TCA_SPLIT_SPLITM_bm);
	TCA0.SPLIT.CTRLB |= 0x20;
	//TCA0.SPLIT.INTCTRL |= (TCA_SPLIT_LUNF_bm);
	
	TCA0.SPLIT.CTRLA |= (TCA_SPLIT_CLKSEL_DIV256_gc) | (TCA_SPLIT_ENABLE_bm);
}