/*
* RoboterArm.c
*
* Created: 05.01.2024 17:12:57
* Author : nilsk
*/
#define F_CPU 20000000

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "UART.h"
#include "motor.h"

int j=0;

long debugDelay;

void clkInit(void){
	CPU_CCP = 0xD8;
	CLKCTRL.MCLKCTRLB = 0x00;
	//CPU_CCP = 0xD8;
	//CLKCTRL.MCLKCTRLA = 0x80;
	CPU_CCP = 0xD8;
	CLKCTRL.OSC20MCTRLA = 0x02;
}


int main(void)
{
	PORTA.DIR |= 0xF0;
	PORTB.DIR |= 0x03;
	PORTC.DIR |= 0x1E;
	
	clkInit();
	
	USART_init();
	
	sei();
	
	printString("homing");
	
	stepperInit();
	moveServo(0);
	
	printString("$OK");
	
	while (1)
	{
		handleStepper();
		decodeCommand();
		/*if(getPosition(A) <= 10){
			setPosition(A, 1000);
			//setPosition(Z, 10000);
		}
		if (getPosition(A) >= 999)
		{
			setPosition(A, 0);
			//setPosition(Z, 0);
		}*/
		
		
	}
}

