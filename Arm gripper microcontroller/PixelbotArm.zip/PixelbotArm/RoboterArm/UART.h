/*
 * UART.h
 *
 * Created: 13.11.2018 12:56:46
 *  Author: nilsk
 */ 


#ifndef UART_H_
#define UART_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "motor.h"

#define BUFFER 40

#define USART0_BAUD_RATE(BAUD_RATE) ((float)20000000 * 64 / (16 * (float)BAUD_RATE))

int8_t USART_init(void);

void USART_write(const uint8_t data);

void printString(const char myString[]);

uint32_t string2uint32 (char *ch);

void decodeCommand(void);

void resetReceiver(void);

#endif /* UART_H_ */