/*
 * motor.h
 *
 * Created: 10.01.2024 01:04:22
 *  Author: nilsk
 */ 

//PA1 Tx
//PA2 Rx

//PB0 Y Step
//PB1 Y En
//PA7 Y Dir

//PA6 Z Step
//PA5 Z En
//PA4 Z Dir

//PC3 A Step
//PC2 A En
//PC1 A Dir

//PA3 Y-Emin
//PB2 Z-Emin
//PB4 Z-Emax
//PB5 A-Emin

//PC4 B (Servo)

#ifndef MOTOR_H_
#define MOTOR_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#define Y 0
#define Z 1
#define A 2

#define ServoMax 115 //158
#define ServoMin 72 //76

#define motorCount 3

void stepperInit(void);

void handleStepper(void);

void timerBInit(void);

void disableMotor (int m);

void enableMotor (int m);

void dirMotor (int m, bool d);

bool readEndstop (int m);

void stepMotor (int m);

void homeMotor (int m);

void setPosition (int m, uint32_t p, bool state);
uint32_t getPosition (int m);

void controllPosition(int m);

void moveServo(int per);

void timerAInit(void);

#endif /* MOTOR_H_ */